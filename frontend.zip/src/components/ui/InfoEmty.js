const InfoEmty = ({
  type
}) => {
  return(
    <div className='text-[red] text-sm mt-1'>
      {type} không được để trống.
    </div>
  )
};
export default InfoEmty;