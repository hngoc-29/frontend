import ForgetPassword from './ForgetPassword';
const quenMatKhau = () => {
  return (
    <>
      <ForgetPassword />
    </>
  );
}
export default quenMatKhau;