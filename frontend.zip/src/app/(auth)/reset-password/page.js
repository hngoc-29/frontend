import ResetPassword from './ResetPassword';

const ResetPasswordPage = () => {
  return(
    <ResetPassword />
  )
};
export default ResetPasswordPage;