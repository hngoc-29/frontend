import Login from './Login';

// Add metadata
export const metadata = {
  title: 'Đăng Nhập',
  description: 'Trang đăng nhập cho ứng dụng của bạn',
};

const dangNhap = () => {
  return (
    <>
      <Login />
    </>
  );
}
export default dangNhap;