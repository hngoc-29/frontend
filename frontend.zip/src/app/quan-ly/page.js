import Main from "./Main";
// Add metadata
export const metadata = {
    title: 'Quản Lý',
    description: 'Trang quản lý cho ứng dụng của bạn',
};
export default function Page() {
    return (
        <div>
            <Main />
        </div>
    );
}